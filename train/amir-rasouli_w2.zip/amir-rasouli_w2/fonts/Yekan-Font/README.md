# Yekan Font

Download: https://github.com/DediData/Yekan-Font/releases

```css
/* Webfont: Yekan */
@font-face {
	font-family: 'Yekan';
	src:	url('Yekan.eot'); /* IE9 Compat Modes */
	src:	url('Yekan.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
			url('Yekan.woff2') format('woff2'), /* Modern Browsers */
			url('Yekan.woff') format('woff'), /* Modern Browsers */
			url('Yekan.otf') format('opentype'), /* Open Type Font */	
			url('Yekan.ttf') format('truetype'); /* Safari, Android, iOS */
	font-weight: normal;
	font-style: normal;
	text-rendering: optimizeLegibility;
	font-display: auto;
}
```

Created on FontLab by Farhad Sakhaei (https://dedidata.com)

Analog letter design by Masood Sepehr (http://masoodsepehr.com)
